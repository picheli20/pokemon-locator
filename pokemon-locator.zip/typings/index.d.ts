/// <reference path="globals/es6-shim/index.d.ts" />
/// <reference path="globals/google.maps/index.d.ts" />
