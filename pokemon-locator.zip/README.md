# Pokemon Locator

For nexts step:

* Detect the nearby pokemon in background with push notifications.
* Better pokemon detail.
* Possiblity to filter.

Data from : [PokeVision](pokevision.com)

![Preview](http://i.imgur.com/oWVRf6D.jpg)

Doing the .README sorry :(

You can check the [Ionic 2 Official tutorial to know how to install](http://ionicframework.com/docs/v2/getting-started/tutorial/).